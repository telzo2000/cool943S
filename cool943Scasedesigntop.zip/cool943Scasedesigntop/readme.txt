These are the components of the keyboard case.
The red line is the inner cutline.
The black line is the outer cutline.
The blue line(word "cool943S") is graving zone.
