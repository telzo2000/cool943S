These are the components of the keyboard case.
The red line is the inner cutline.
The black line is the outer cutline.
